namespace Calc;

internal class Program
{
    static void Main(string[] args)
    {
        var calculator = new Calculator();
        var minCalculator = new MinCalculator();

        Console.WriteLine($"2 + 3 + 1 = {calculator.AddWithInc(2, 3)}");
        Console.WriteLine($"4 / 2 = {calculator.Div(4, 2)}");
        Console.WriteLine($"Минимальное из чисел 2 и 5: {minCalculator.GetMin(2, 5)}");
        Console.WriteLine($"Минимальное из чисел 3, 1 и 2: {minCalculator.GetMin(3, 1, 2)}");
    }
}
