namespace Calc;

/// <summary>
/// Выполняет поиск минимального числа.
/// </summary>
public class MinCalculator
{
    /// <summary>
    /// Находит минимальное из двух чисел.
    /// </summary>
    public int GetMin(int a, int b)
    {
        return a < b ? a : b;
    }

    /// <summary>
    /// Находит минимальное из трёх чисел.
    /// </summary>
    public int GetMin(int a, int b, int c)
    {
        int min = a;

        if (b < min)
        {
            min = b;
        }

        if (c < min)
        {
            min = c;
        }

        return min;
    }
}
