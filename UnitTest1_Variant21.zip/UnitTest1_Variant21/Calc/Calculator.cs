namespace Calc;

/// <summary>
/// Выполняет простые математические операции над числами.
/// </summary>
public class Calculator
{
    /// <summary>
    /// Делит первое число на второе.
    /// </summary>
    /// <param name="n1">Делимое.</param>
    /// <param name="n2">Делитель.</param>
    /// <returns>Результат деления.</returns>
    /// <exception cref="DivideByZeroException">
    /// Возникает, если второе число равно нулю.
    /// </exception>
    public double Div(double n1, double n2)
    {
        if (n2 == 0.0)
        {
            throw new DivideByZeroException("Деление на ноль невозможно.");
        }

        return n1 / n2;
    }

    /// <summary>
    /// Складывает два числа и увеличивает результат на единицу.
    /// </summary>
    public double AddWithInc(double n1, double n2)
    {
        return n1 + n2 + 1;
    }
}
