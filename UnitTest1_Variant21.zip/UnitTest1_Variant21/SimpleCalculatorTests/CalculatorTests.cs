using Calc;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SimpleCalculatorTests;

[TestClass]
public class CalculatorTests
{
    /// <summary>
    /// Проверка сложения чисел 2 и 3 с увеличением результата на единицу.
    /// </summary>
    [TestMethod]
    public void AddWithInc_2Plus3Inc1_Returned6()
    {
        // Arrange
        var calculator = new Calculator();
        double firstNumber = 2;
        double secondNumber = 3;
        double expected = 6;

        // Act
        double actual = calculator.AddWithInc(firstNumber, secondNumber);

        // Assert
        Assert.AreEqual(expected, actual);
    }

    /// <summary>
    /// Проверка деления числа 4 на 2.
    /// </summary>
    [TestMethod]
    public void Div_4Div2_Returned2()
    {
        // Arrange
        var calculator = new Calculator();
        double dividend = 4;
        double divisor = 2;
        double expected = 2;

        // Act
        double actual = calculator.Div(dividend, divisor);

        // Assert
        Assert.AreEqual(expected, actual);
    }

    /// <summary>
    /// Проверка возникновения исключения при делении на ноль.
    /// </summary>
    [TestMethod]
    [ExpectedException(typeof(DivideByZeroException))]
    public void Div_4Div0_ThrowsDivideByZeroException()
    {
        // Arrange
        var calculator = new Calculator();
        double dividend = 4;
        double divisor = 0;

        // Act
        calculator.Div(dividend, divisor);

        // Assert выполняется атрибутом ExpectedException.
    }
}
