using Calc;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SimpleCalculatorTests;

[TestClass]
public class MinCalculatorTests
{
    [TestMethod]
    public void GetMin_TwoNumbers_FirstNumberIsMinimum_Returned2()
    {
        // Arrange
        var calculator = new MinCalculator();
        int firstNumber = 2;
        int secondNumber = 5;
        int expected = 2;

        // Act
        int actual = calculator.GetMin(firstNumber, secondNumber);

        // Assert
        Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void GetMin_TwoNumbers_SecondNumberIsMinimum_Returned2()
    {
        // Arrange
        var calculator = new MinCalculator();
        int firstNumber = 5;
        int secondNumber = 2;
        int expected = 2;

        // Act
        int actual = calculator.GetMin(firstNumber, secondNumber);

        // Assert
        Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void GetMin_ThreeNumbers_FirstNumberIsMinimum_Returned1()
    {
        // Arrange
        var calculator = new MinCalculator();
        int firstNumber = 1;
        int secondNumber = 2;
        int thirdNumber = 3;
        int expected = 1;

        // Act
        int actual = calculator.GetMin(firstNumber, secondNumber, thirdNumber);

        // Assert
        Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void GetMin_ThreeNumbers_SecondNumberIsMinimum_Returned1()
    {
        // Arrange
        var calculator = new MinCalculator();
        int firstNumber = 2;
        int secondNumber = 1;
        int thirdNumber = 3;
        int expected = 1;

        // Act
        int actual = calculator.GetMin(firstNumber, secondNumber, thirdNumber);

        // Assert
        Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void GetMin_ThreeNumbers_ThirdNumberIsMinimum_Returned1()
    {
        // Arrange
        var calculator = new MinCalculator();
        int firstNumber = 2;
        int secondNumber = 3;
        int thirdNumber = 1;
        int expected = 1;

        // Act
        int actual = calculator.GetMin(firstNumber, secondNumber, thirdNumber);

        // Assert
        Assert.AreEqual(expected, actual);
    }
}
